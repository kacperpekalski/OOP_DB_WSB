package pl.wsb.examples.car;

// an enum representing the color //
public enum Color {

    // possible values //
    WHITE,
    BLACK,
    RED,
    BLUE
}
