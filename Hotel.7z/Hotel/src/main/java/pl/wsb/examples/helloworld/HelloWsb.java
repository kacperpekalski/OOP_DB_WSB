package pl.wsb.examples.helloworld;

public class HelloWsb {

    public static void main(String[] args) {
        System.out.println("Hello WSB!");
    }
}
