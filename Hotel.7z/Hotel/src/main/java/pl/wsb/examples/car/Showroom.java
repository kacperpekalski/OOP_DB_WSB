package pl.wsb.examples.car;

import java.util.List;

// interface //
public interface Showroom {

    // method declarations //
    void addCar(Car newCar);
    List<String> getAllSummaries();
}
